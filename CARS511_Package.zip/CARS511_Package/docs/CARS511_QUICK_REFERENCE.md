# CARS 511 Request Builder — Quick Reference

A one-page guide for field/RCE staff. Open **`iadot-wz-request-standalone.html`** (double-click, or from your intranet). Everything works from one file; internet is only needed for the map tiles and the live lookups below.

---

## Build a request in 6 steps

1. **Mark the work zone.** Click the road for the **begin** point, then the **end** point — the segment snaps to the Iowa DOT centerline and auto-fills the **route**, direction, **posted mileposts**, county, speed limit, nearest **RCE office**, and the **maintenance garage** with its phone. *(In the field, tap **📍 Use my location** instead of clicking.)*
   - The route is read from the **middle** of the segment, not the first pin, so a closure that starts at an intersection is not labelled with the cross street.
   - If the selection crosses from one route onto another it says so, and offers **✂ Split into two closures at the boundary** — each side then carries mileposts measured on its own route. The TMC has to file one 511 entry per route, so the request should arrive already split.
2. **Check it's not already filed.** Press **🔁 Check for existing closures / duplicates**. Green = clear to file. Red = an existing 511 closure is here — tap **load & extend** to update it instead of filing a duplicate.
3. **Pull in the details** (each is a button; results are tappable):
   - **🏗️ Find DOT project #** — programmed (5-year) + letting projects within ~1 mile → each is **drawn on the map** with its distance, so you can see which one sits on your closure before picking. Tap the number or the shape.
   - **🌉 Scan NBI clearances (route + detour)** — lowest bridge clearance on the route *and* the detour, plus posted restrictions → **Apply** fills height/width.
   - **🔶 Scan DMS, arrow boards & Street Smart (IWZ)** — tap devices to add; a **Street Smart (SS/SSR)** unit marks it an **Intelligent Work Zone**.
   - The **lane hint** under "Traffic impact" tells you how many lanes exist that direction — pick the matching impact.
4. **Set the schedule.** Built the way the TMC enters it in OpenTMS. Each **segment** is a date span, a
   daily time window, and — if it repeats — the days of the week it runs on. Add one segment per pattern:
   a closure that starts later on Sunday nights is its own segment, because that is how it goes into 511.
   A **single day** or a **single overnight** is just one segment with recurring left unticked; there is no
   week count to invent. Overnight windows are detected and marked as ending the following morning.
5. **Detour.** Answer **Does this closure have a detour?** — the section only opens if you say yes. You can
   save **more than one**, named by route and direction (e.g. *I-80 eastbound detour*). If a detour you draw
   runs along one of your own closures, it says so rather than routing traffic into a road you are closing.
6. **Review readiness.** Press **✓ Check readiness** — it flags any required field still empty before you submit.
**It remembers between requests.** Your name and email, the 24-hr contact (as a growing dropdown — pick a
name and its number fills in), the RCE cc address **per office**, and the district tech **per garage**.
Anything you type is never overwritten by a later map move.

**More than one closure on a request?** Save each with **➕ Save closure & add another**. The PDF then carries
the overview map plus **one page per closure** — its own map and its own mileposts — because each is filed as
its own 511 entry.

7. **Submit.** Choose one:
   - **📝 Fill official 511 PDF** — downloads the filled Iowa 511 form.
   - **📋 Fill 511 site (copy fields)** — opens the SeamlessDocs form + per-field copy buttons.
   - **✉️ Email TMC (cc RCE)** — drafts the email (text auto-copied; Gmail fallback link if no mail app).
   - **🗄️ Submit to database** — posts directly to your system (if IT has set it up).

> Tip: **💾 Save project** keeps a request to reload later; **🗑 New** clears everything.

---

## What's new (Aug 2026)

- **📍 GPS "use my location"** — set the begin/end point from the field.
- **Duplicate/overlap check** against the live 511 feed, with one-tap **load & extend**.
- **Load & extend** an existing 511 event (auto-fills route, dates, description, mileposts).
- **Find DOT project #** from the 5-Year Program + letting/bid layers.
- **NBI clearances on route *and* detour** — now from the **live federal NBI** (statewide, fresher) + Iowa **posted restrictions**.
- **DMS / arrow boards / Street Smart (IWZ)** device scan — correct IWZ meaning (Street Smart deployment, not arrow boards).
- **Full 26-choice traffic-impact dropdown** (matches the official form) + a **lanes-available** hint.
- **Additional info / notes** field that consolidates devices and your notes into the form's Additional-info box.
- **Readiness check** before submitting; **Share route/detour maps**; **Database submit** + JSON export.
- The request email now arrives in the **same field order and wording as the SeamlessDocs 511 form**, so the
  TMC reads it exactly where they expect each value.
- Basemap is **OpenStreetMap** (Esri's still showed IA 401, decommissioned in 1991); Esri stays selectable.
- **Cameras were removed** at the TMC's request — they were never used to fill the request.
- The **DMS field is a yes/no request**: the TMC composes sign text to the statewide MUTCD format.

---

## Connected data services

All are **read-only GET** requests and (except where noted) **CORS-open**, so the standalone file can call them directly. IT can use this list for allow-listing.

### Iowa DOT ArcGIS (org `8lRhdTsQyJpO52F1`)
| Service | Used for |
|---|---|
| `Road_Network_View` | Centerline geometry, **NUMBER_LANES** + AADT/truck AADT (HPMS-equivalent) |
| `Reference_Post_View` | Posted mileposts, route & direction |
| `CARS511_Iowa_View` | Live 511 events — **Load from live feed** + **duplicate check** |
| `DMS_View` | DMS signs, arrow boards, Street Smart (IWZ) devices |
| `Leg17Bridges` | Posted bridge restrictions (`Bridge_Posting`) |
| `Resident_Construction_Office_view` | Nearest RCE office auto-detect |
| `Iowa_DOT_Five_Year_Program_Project_Data_V2_Public_VIEW` | 5-Year Program project codes |
| `Project_Scheduling_Public_Bid_Line_View` | Letting/bid **project numbers** |

### Federal
| Service | Used for |
|---|---|
| `NTAD_National_Bridge_Inventory` (org `xOi1kZaI0eWDREZv`) | **Live bridge clearances** (item 54B vertical underclearance), statewide |

### Other endpoints
| Endpoint | Used for | Notes |
|---|---|---|
| `corridor-bridges.pages.dev/bridges.json` | Static NBI corridor fallback | Used only if the live NBI service is unavailable |
| `geo.fcc.gov/api/census/area` | County from lat/lon | Works from `file://` |
| `router.project-osrm.org` | Road-following geometry (detours + fallback) | Public OSRM |
| OpenStreetMap **Nominatim** | Reverse-geocode road name | Optional toggle; blocked from `file://` (degrades gracefully) |
| `www.google.com/maps/dir/` | Shareable route/detour map links | Opens in a browser tab (not an API call) |
| `mail.google.com/mail/` | Gmail compose fallback | Used only if no desktop mail app |
| `iowadot.seamlessdocs.com` | Official 511 web form | Opened for copy/paste submission |
| *your* `…/api/cars511` | **Optional** database submit | Configured per device (see `CARS511_DATABASE_INTEGRATION.md`) |

Plus map tiles from OpenStreetMap. No credentials are required for any lookup; only the optional database submit uses an auth token you configure.
